from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional

from app.config import NodeConfig
from app.models import HardwareType, ModelTier, NodeStatus


@dataclass
class RuntimeNode:
    config: NodeConfig
    healthy: bool = True
    active_requests: int = 0
    consecutive_failures: int = 0
    last_health_check: float = 0.0
    circuit_open_until: float = 0.0

    @property
    def name(self) -> str:
        return self.config.name

    @property
    def hardware_type(self) -> HardwareType:
        return self.config.hardware_type

    @property
    def base_url(self) -> str:
        return self.config.base_url.rstrip("/")

    @property
    def capacity_score(self) -> int:
        return self.config.capacity_score

    @property
    def max_context_tokens(self) -> int:
        return self.config.max_context_tokens

    @property
    def models(self) -> Dict[str, str]:
        return self.config.models

    def supports_model(self, model: str) -> bool:
        return model in set(self.models.values())

    def supports_tier(self, tier: ModelTier) -> bool:
        return tier.value in self.models

    def model_for_tier(self, tier: ModelTier) -> Optional[str]:
        return self.models.get(tier.value)

    def load_score(self) -> float:
        return self.active_requests / max(self.capacity_score, 1)

    def circuit_is_open(self) -> bool:
        return time.time() < self.circuit_open_until

    def mark_failure(self, failure_threshold: int, cooldown_seconds: float) -> None:
        self.consecutive_failures += 1
        self.healthy = False
        if self.consecutive_failures >= failure_threshold:
            self.circuit_open_until = time.time() + cooldown_seconds

    def mark_success(self) -> None:
        self.consecutive_failures = 0
        self.healthy = True
        self.circuit_open_until = 0.0

    def to_status(self) -> NodeStatus:
        return NodeStatus(
            name=self.name,
            hardware_type=self.hardware_type,
            base_url=self.base_url,
            enabled=self.config.enabled,
            healthy=self.healthy and not self.circuit_is_open(),
            active_requests=self.active_requests,
            capacity_score=self.capacity_score,
            max_context_tokens=self.max_context_tokens,
            models=self.models,
            consecutive_failures=self.consecutive_failures,
            circuit_open_until=self.circuit_open_until,
        )


class NodeRegistry:
    def __init__(self, nodes: Iterable[NodeConfig]) -> None:
        self.nodes: List[RuntimeNode] = [RuntimeNode(config=node) for node in nodes]

    def all(self) -> List[RuntimeNode]:
        return list(self.nodes)

    def healthy_candidates(
        self,
        model: str,
        total_tokens: int,
        preferred_hardware: Optional[HardwareType],
    ) -> List[RuntimeNode]:
        candidates: List[RuntimeNode] = []
        for node in self.nodes:
            if node.circuit_is_open():
                continue
            if not node.healthy:
                continue
            if not node.supports_model(model):
                continue
            if total_tokens > node.max_context_tokens:
                continue
            if preferred_hardware and node.hardware_type != preferred_hardware:
                continue
            candidates.append(node)
        return candidates

    def fallback_candidates(
        self,
        model: str,
        total_tokens: int,
        exclude_name: str,
    ) -> List[RuntimeNode]:
        candidates: List[RuntimeNode] = []
        for node in self.nodes:
            if node.name == exclude_name:
                continue
            if node.circuit_is_open():
                continue
            if not node.healthy:
                continue
            if not node.supports_model(model):
                continue
            if total_tokens > node.max_context_tokens:
                continue
            candidates.append(node)
        return candidates

    def best_model_for_tier(self, tier: ModelTier, preferred_hardware: Optional[HardwareType]) -> str:
        """Choose a model tag that exists in the loaded node inventory."""
        ordered_nodes = self.nodes
        if preferred_hardware:
            preferred = [n for n in ordered_nodes if n.hardware_type == preferred_hardware and n.supports_tier(tier)]
            if preferred:
                return preferred[0].model_for_tier(tier) or next(iter(preferred[0].models.values()))

        for node in ordered_nodes:
            model = node.model_for_tier(tier)
            if model:
                return model

        # Graceful degradation: if a large/code tier is not configured, fall back to medium then small.
        for fallback in (ModelTier.MEDIUM, ModelTier.SMALL):
            for node in ordered_nodes:
                model = node.model_for_tier(fallback)
                if model:
                    return model

        raise RuntimeError("No configured models found in node registry")

    def statuses(self) -> List[NodeStatus]:
        return [node.to_status() for node in self.nodes]
