from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List

import yaml
from pydantic import BaseModel, HttpUrl
from pydantic_settings import BaseSettings, SettingsConfigDict

from app.models import HardwareType, RouterMode


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    ollama_router_mode: RouterMode = RouterMode.MOCK
    ollama_router_config: str = "config/nodes.yaml"
    ollama_router_profile: str = "default"
    ollama_router_log_level: str = "INFO"

    health_check_timeout_seconds: float = 2.0
    request_timeout_seconds: float = 180.0
    max_health_age_seconds: float = 15.0
    circuit_breaker_failures: int = 3
    circuit_breaker_cooldown_seconds: float = 30.0


class NodeConfig(BaseModel):
    name: str
    hardware_type: HardwareType
    base_url: str
    enabled: bool = True
    capacity_score: int = 1
    max_context_tokens: int = 32768
    models: Dict[str, str]


@dataclass(frozen=True)
class LoadedConfig:
    settings: Settings
    nodes: List[NodeConfig]


def load_config() -> LoadedConfig:
    settings = Settings()
    config_path = Path(settings.ollama_router_config)

    if not config_path.exists():
        raise FileNotFoundError(f"Router config not found: {config_path}")

    raw = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    profiles = raw.get("profiles", {})

    if settings.ollama_router_profile not in profiles:
        available = ", ".join(sorted(profiles.keys()))
        raise ValueError(
            f"Profile '{settings.ollama_router_profile}' not found in {config_path}. "
            f"Available profiles: {available}"
        )

    profile = profiles[settings.ollama_router_profile]
    key = "mock_nodes" if settings.ollama_router_mode == RouterMode.MOCK else "real_nodes"
    raw_nodes = profile.get(key, [])
    nodes = [NodeConfig(**node) for node in raw_nodes if node.get("enabled", True)]

    if not nodes:
        raise ValueError(
            f"No enabled nodes found for mode={settings.ollama_router_mode.value}, "
            f"profile={settings.ollama_router_profile}."
        )

    return LoadedConfig(settings=settings, nodes=nodes)
