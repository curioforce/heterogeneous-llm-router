from __future__ import annotations

import re
from typing import List, Optional

from app.models import (
    ChatCompletionRequest,
    ContentType,
    HardwareType,
    ModelTier,
    RouteEvaluation,
)
from app.registry import NodeRegistry


CODE_PATTERNS = [
    r"```",
    r"\bdef\s+\w+\(",
    r"\bclass\s+\w+",
    r"\bimport\s+\w+",
    r"\bfrom\s+\w+\s+import\b",
    r"\bfunction\s+\w+\(",
    r"\bconst\s+\w+\s*=",
    r"\blet\s+\w+\s*=",
    r"\bSELECT\s+.+\bFROM\b",
    r"Traceback \(most recent call last\)",
]

KEYWORDS = {
    ContentType.ANALYSIS: [
        "analyze", "analysis", "strategy", "benchmark", "compare", "evaluate",
        "deep dive", "architecture", "production", "risk", "market", "legal", "financial",
    ],
    ContentType.CODE: [
        "code", "debug", "fix", "refactor", "typescript", "python", "javascript",
        "docker", "kubernetes", "api", "fastapi", "flask", "error", "stack trace",
    ],
    ContentType.CREATIVE: [
        "write a story", "creative", "character", "logo", "tagline", "script", "poem",
    ],
    ContentType.TRANSLATION: ["translate", "translation", "japanese", "english", "日本語", "英語"],
    ContentType.SUMMARIZATION: ["summarize", "summary", "tl;dr", "recap"],
    ContentType.EXTRACTION: ["extract", "parse", "json", "csv", "table"],
}

COMPLEXITY_KEYWORDS = [
    "production", "architecture", "distributed", "scalable", "security", "compliance",
    "legal", "financial", "strategy", "benchmark", "optimize", "debug", "refactor",
    "root cause", "multi-step", "research", "deep dive", "investor", "business plan",
]


def estimate_tokens(text: str) -> int:
    """Cheap approximation. Replace with model-specific tokenizer in high-stakes systems."""
    if not text:
        return 1
    # Japanese/CJK text often packs more meaning per character than English. This heuristic is intentionally conservative.
    cjk_chars = len(re.findall(r"[\u3040-\u30ff\u3400-\u9fff]", text))
    non_cjk_chars = max(0, len(text) - cjk_chars)
    return max(1, int(cjk_chars * 0.9 + non_cjk_chars / 4))


def joined_prompt(request: ChatCompletionRequest) -> str:
    return "\n".join(message.content for message in request.messages)


def detect_content_type(text: str) -> ContentType:
    lower = text.lower()

    if any(re.search(pattern, text, flags=re.IGNORECASE | re.DOTALL) for pattern in CODE_PATTERNS):
        return ContentType.CODE

    scores = {}
    for content_type, words in KEYWORDS.items():
        scores[content_type] = sum(1 for word in words if word in lower)

    best_type, best_score = max(scores.items(), key=lambda item: item[1])
    if best_score > 0:
        return best_type

    if len(text) < 500:
        return ContentType.CHAT

    return ContentType.UNKNOWN


def complexity_score(text: str, prompt_tokens: int, max_tokens: int, priority: str) -> int:
    lower = text.lower()
    score = 0

    if prompt_tokens > 1_000:
        score += 1
    if prompt_tokens > 4_000:
        score += 2
    if prompt_tokens > 12_000:
        score += 3

    if max_tokens > 1_000:
        score += 1
    if max_tokens > 2_500:
        score += 2

    score += min(4, sum(1 for word in COMPLEXITY_KEYWORDS if word in lower))

    if priority == "high":
        score += 2
    elif priority == "low":
        score -= 1

    return max(0, min(score, 10))


def choose_model_tier(
    content_type: ContentType,
    score: int,
    prompt_tokens: int,
    priority: str,
) -> ModelTier:
    if content_type == ContentType.CODE:
        return ModelTier.CODE
    if priority == "high" or score >= 7 or prompt_tokens > 12_000:
        return ModelTier.LARGE
    if score >= 3 or prompt_tokens > 2_000 or content_type == ContentType.ANALYSIS:
        return ModelTier.MEDIUM
    return ModelTier.SMALL


def choose_preferred_hardware(
    request: ChatCompletionRequest,
    tier: ModelTier,
    content_type: ContentType,
    prompt_tokens: int,
    score: int,
) -> Optional[HardwareType]:
    if request.preferred_hardware:
        return request.preferred_hardware

    if tier in {ModelTier.LARGE, ModelTier.CODE}:
        return HardwareType.NVIDIA_GPU
    if request.priority.value == "high":
        return HardwareType.NVIDIA_GPU
    if prompt_tokens > 8_000 or score >= 6:
        return HardwareType.NVIDIA_GPU

    # Preserve expensive GPU capacity for heavy work.
    return HardwareType.APPLE_SILICON


def evaluate_request(request: ChatCompletionRequest, registry: NodeRegistry) -> RouteEvaluation:
    text = joined_prompt(request)
    prompt_tokens = estimate_tokens(text)
    total_tokens = prompt_tokens + request.max_tokens
    content_type = detect_content_type(text)
    score = complexity_score(text, prompt_tokens, request.max_tokens, request.priority.value)
    tier = choose_model_tier(content_type, score, prompt_tokens, request.priority.value)
    preferred_hw = choose_preferred_hardware(request, tier, content_type, prompt_tokens, score)

    selected_model = request.model or registry.best_model_for_tier(tier, preferred_hw)

    reasoning: List[str] = [
        f"estimated_prompt_tokens={prompt_tokens}",
        f"content_type={content_type.value}",
        f"complexity_score={score}",
        f"selected_model_tier={tier.value}",
    ]

    if request.model:
        reasoning.append("client supplied model, so router preserved it")
    else:
        reasoning.append(f"router selected model '{selected_model}' for tier '{tier.value}'")

    if preferred_hw:
        reasoning.append(f"preferred_hardware={preferred_hw.value}")

    return RouteEvaluation(
        prompt_chars=len(text),
        estimated_prompt_tokens=prompt_tokens,
        estimated_total_tokens=total_tokens,
        content_type=content_type,
        complexity_score=score,
        selected_model_tier=tier,
        selected_model=selected_model,
        preferred_hardware=preferred_hw,
        reasoning=reasoning,
    )
