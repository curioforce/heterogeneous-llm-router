from __future__ import annotations

from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class HardwareType(str, Enum):
    APPLE_SILICON = "apple_silicon"
    NVIDIA_GPU = "nvidia_gpu"


class RouterMode(str, Enum):
    MOCK = "mock"
    REAL = "real"


class RequestPriority(str, Enum):
    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"


class ContentType(str, Enum):
    CHAT = "chat"
    CODE = "code"
    ANALYSIS = "analysis"
    CREATIVE = "creative"
    TRANSLATION = "translation"
    SUMMARIZATION = "summarization"
    EXTRACTION = "extraction"
    UNKNOWN = "unknown"


class ModelTier(str, Enum):
    SMALL = "small"
    MEDIUM = "medium"
    LARGE = "large"
    CODE = "code"


class ChatMessage(BaseModel):
    role: str = Field(..., examples=["user", "system", "assistant"])
    content: str


class ChatCompletionRequest(BaseModel):
    """OpenAI-ish request accepted by the router.

    model is intentionally optional. If omitted, the router chooses the model.
    You may still provide model to force a specific Ollama model tag.
    """

    messages: List[ChatMessage]
    model: Optional[str] = None
    temperature: float = 0.7
    max_tokens: int = 512
    priority: RequestPriority = RequestPriority.NORMAL
    preferred_hardware: Optional[HardwareType] = None
    allow_fallback: bool = True
    stream: bool = False
    options: Dict[str, Any] = Field(default_factory=dict)


class RouteEvaluation(BaseModel):
    prompt_chars: int
    estimated_prompt_tokens: int
    estimated_total_tokens: int
    content_type: ContentType
    complexity_score: int
    selected_model_tier: ModelTier
    selected_model: str
    preferred_hardware: Optional[HardwareType]
    reasoning: List[str]


class ChatCompletionResponse(BaseModel):
    selected_model: str
    selected_model_tier: ModelTier
    backend_name: str
    backend_hardware: HardwareType
    route: RouteEvaluation
    response: Dict[str, Any]


class NodeStatus(BaseModel):
    name: str
    hardware_type: HardwareType
    base_url: str
    enabled: bool
    healthy: bool
    active_requests: int
    capacity_score: int
    max_context_tokens: int
    models: Dict[str, str]
    consecutive_failures: int
    circuit_open_until: float
