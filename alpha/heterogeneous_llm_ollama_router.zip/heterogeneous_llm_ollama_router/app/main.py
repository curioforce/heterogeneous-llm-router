from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from typing import Any, Dict

from fastapi import FastAPI

from app.classifier import evaluate_request
from app.config import load_config
from app.models import ChatCompletionRequest, ChatCompletionResponse
from app.registry import NodeRegistry
from app.router import LLMRouter

loaded = load_config()
logging.basicConfig(
    level=getattr(logging, loaded.settings.ollama_router_log_level.upper(), logging.INFO),
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger("ollama-router")

registry = NodeRegistry(loaded.nodes)
router = LLMRouter(registry=registry, settings=loaded.settings)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info(
        "Starting router mode=%s profile=%s nodes=%s",
        loaded.settings.ollama_router_mode.value,
        loaded.settings.ollama_router_profile,
        [node.name for node in registry.all()],
    )
    await router.refresh_health_checks()
    yield


app = FastAPI(
    title="Production Ollama Hardware Router",
    description="Routes LLM traffic to Apple Silicon or NVIDIA Ollama nodes with auto model selection.",
    version="1.0.0",
    lifespan=lifespan,
)


@app.get("/health")
async def health() -> Dict[str, Any]:
    await router.refresh_health_checks()
    statuses = registry.statuses()
    healthy = [node for node in statuses if node.healthy]
    return {
        "status": "ok" if healthy else "degraded",
        "mode": loaded.settings.ollama_router_mode.value,
        "healthy_backend_count": len(healthy),
        "backend_count": len(statuses),
    }


@app.get("/nodes")
async def nodes() -> Dict[str, Any]:
    await router.refresh_health_checks()
    return {"nodes": [status.model_dump() for status in registry.statuses()]}


@app.post("/route/evaluate")
async def route_evaluate(request: ChatCompletionRequest) -> Dict[str, Any]:
    route = evaluate_request(request, registry)
    return route.model_dump()


@app.post("/v1/chat/completions", response_model=ChatCompletionResponse)
async def chat_completions(request: ChatCompletionRequest) -> ChatCompletionResponse:
    if request.stream:
        # This reference gateway intentionally disables streaming because streaming fallback is harder:
        # once bytes are sent, you cannot transparently retry on another node.
        request.stream = False

    final_node, route, backend_response = await router.run(request)

    return ChatCompletionResponse(
        selected_model=route.selected_model,
        selected_model_tier=route.selected_model_tier,
        backend_name=final_node.name,
        backend_hardware=final_node.hardware_type,
        route=route,
        response=backend_response,
    )
