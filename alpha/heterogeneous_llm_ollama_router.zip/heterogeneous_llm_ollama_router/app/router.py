from __future__ import annotations

import logging
import random
import time
from typing import List, Tuple

from fastapi import HTTPException

from app.classifier import evaluate_request
from app.clients import OllamaClient
from app.config import Settings
from app.models import ChatCompletionRequest, HardwareType, RequestPriority, RouteEvaluation
from app.registry import NodeRegistry, RuntimeNode

logger = logging.getLogger("ollama-router")


class LLMRouter:
    def __init__(self, registry: NodeRegistry, settings: Settings) -> None:
        self.registry = registry
        self.settings = settings
        self.client = OllamaClient(timeout_seconds=settings.request_timeout_seconds)

    async def refresh_health_checks(self) -> None:
        now = time.time()
        for node in self.registry.all():
            if node.circuit_is_open():
                continue
            if now - node.last_health_check < self.settings.max_health_age_seconds:
                continue
            healthy = await self.client.health(node, self.settings.health_check_timeout_seconds)
            node.last_health_check = now
            if healthy:
                node.mark_success()
            else:
                node.mark_failure(
                    self.settings.circuit_breaker_failures,
                    self.settings.circuit_breaker_cooldown_seconds,
                )

    def route_score(self, node: RuntimeNode, request: ChatCompletionRequest, route: RouteEvaluation) -> float:
        """Lower score wins.

        This intentionally separates policy from inventory:
        - Apple Silicon gets a bias for small/simple/normal work.
        - NVIDIA gets a bias for large/code/high-priority/long-context work.
        - Current load and capacity still matter.
        """
        score = 0.0
        score += node.load_score() * 100.0

        if route.preferred_hardware == node.hardware_type:
            score -= 20.0
        else:
            score += 8.0

        if route.selected_model_tier.value in {"large", "code"}:
            if node.hardware_type == HardwareType.NVIDIA_GPU:
                score -= 25.0
            else:
                score += 25.0

        if route.selected_model_tier.value == "small" and request.priority != RequestPriority.HIGH:
            if node.hardware_type == HardwareType.APPLE_SILICON:
                score -= 20.0
            else:
                score += 8.0

        if request.priority == RequestPriority.HIGH:
            if node.hardware_type == HardwareType.NVIDIA_GPU:
                score -= 20.0
            else:
                score += 12.0

        if request.priority == RequestPriority.LOW:
            if node.hardware_type == HardwareType.APPLE_SILICON:
                score -= 10.0

        # Capacity is a tie-breaker, not the whole policy.
        score -= node.capacity_score * 0.05
        score += random.uniform(0, 0.25)
        return score

    async def choose_node(self, request: ChatCompletionRequest) -> Tuple[RuntimeNode, RouteEvaluation]:
        await self.refresh_health_checks()
        route = evaluate_request(request, self.registry)

        candidates = self.registry.healthy_candidates(
            model=route.selected_model,
            total_tokens=route.estimated_total_tokens,
            preferred_hardware=route.preferred_hardware,
        )

        # If the preferred hardware has no candidate, relax the hardware preference rather than failing early.
        if not candidates:
            candidates = self.registry.healthy_candidates(
                model=route.selected_model,
                total_tokens=route.estimated_total_tokens,
                preferred_hardware=None,
            )
            route.reasoning.append("preferred hardware had no candidate; relaxed hardware preference")

        if not candidates:
            raise HTTPException(
                status_code=503,
                detail=(
                    "No healthy Ollama backend can serve the selected model/context. "
                    f"model={route.selected_model}, estimated_total_tokens={route.estimated_total_tokens}"
                ),
            )

        selected = sorted(candidates, key=lambda n: self.route_score(n, request, route))[0]
        route.reasoning.append(f"selected_backend={selected.name}")
        return selected, route

    async def forward(self, node: RuntimeNode, request: ChatCompletionRequest, route: RouteEvaluation):
        node.active_requests += 1
        try:
            result = await self.client.chat(node, request, route.selected_model)
            node.mark_success()
            return result
        except Exception as exc:
            logger.warning("Backend failed: node=%s error=%s", node.name, exc)
            node.mark_failure(
                self.settings.circuit_breaker_failures,
                self.settings.circuit_breaker_cooldown_seconds,
            )
            raise
        finally:
            node.active_requests -= 1

    async def run(self, request: ChatCompletionRequest) -> Tuple[RuntimeNode, RouteEvaluation, dict]:
        primary, route = await self.choose_node(request)

        try:
            result = await self.forward(primary, request, route)
            return primary, route, result
        except Exception as first_error:
            if not request.allow_fallback:
                raise HTTPException(
                    status_code=502,
                    detail=f"Primary backend {primary.name} failed and fallback is disabled: {first_error}",
                )

        fallbacks = self.registry.fallback_candidates(
            model=route.selected_model,
            total_tokens=route.estimated_total_tokens,
            exclude_name=primary.name,
        )
        fallbacks = sorted(fallbacks, key=lambda n: self.route_score(n, request, route))

        for fallback in fallbacks:
            route.reasoning.append(f"trying_fallback={fallback.name}")
            try:
                result = await self.forward(fallback, request, route)
                route.reasoning.append(f"fallback_success={fallback.name}")
                return fallback, route, result
            except Exception as exc:
                route.reasoning.append(f"fallback_failed={fallback.name}: {exc}")

        raise HTTPException(status_code=502, detail="All candidate backends failed.")
