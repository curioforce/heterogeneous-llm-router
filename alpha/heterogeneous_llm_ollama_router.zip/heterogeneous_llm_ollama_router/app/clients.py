from __future__ import annotations

from typing import Any, Dict, List

import httpx

from app.models import ChatCompletionRequest
from app.registry import RuntimeNode


class OllamaClient:
    """Small async client for Ollama-compatible servers."""

    def __init__(self, timeout_seconds: float) -> None:
        self.timeout = httpx.Timeout(timeout_seconds)

    async def health(self, node: RuntimeNode, timeout_seconds: float = 2.0) -> bool:
        # Ollama does not always expose /health, so we try /api/tags first.
        async with httpx.AsyncClient(timeout=httpx.Timeout(timeout_seconds)) as client:
            try:
                resp = await client.get(f"{node.base_url}/api/tags")
                return 200 <= resp.status_code < 300
            except Exception:
                try:
                    resp = await client.get(f"{node.base_url}/health")
                    return 200 <= resp.status_code < 300
                except Exception:
                    return False

    async def chat(self, node: RuntimeNode, request: ChatCompletionRequest, model: str) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "model": model,
            "messages": [message.model_dump() for message in request.messages],
            "stream": False,
            "options": {
                "temperature": request.temperature,
                "num_predict": request.max_tokens,
                **request.options,
            },
        }

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            resp = await client.post(f"{node.base_url}/api/chat", json=payload)
            resp.raise_for_status()
            return resp.json()
