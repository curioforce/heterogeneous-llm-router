#!/usr/bin/env python3
from __future__ import annotations

import argparse
import time
from typing import Any, Dict, List

import uvicorn
from fastapi import FastAPI
from pydantic import BaseModel, Field


class OllamaMessage(BaseModel):
    role: str
    content: str


class OllamaChatRequest(BaseModel):
    model: str
    messages: List[OllamaMessage]
    stream: bool = False
    options: Dict[str, Any] = Field(default_factory=dict)


def create_app(node_name: str, hardware_type: str, models: List[str], delay: float) -> FastAPI:
    app = FastAPI(title=f"Mock Ollama Node - {node_name}")

    @app.get("/health")
    async def health() -> Dict[str, str]:
        return {"status": "ok", "node_name": node_name, "hardware_type": hardware_type}

    @app.get("/api/tags")
    async def tags() -> Dict[str, Any]:
        now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        return {
            "models": [
                {
                    "name": model,
                    "model": model,
                    "modified_at": now,
                    "size": 1_000_000_000,
                    "digest": f"mock-{model}",
                    "details": {"family": "mock", "parameter_size": model},
                }
                for model in models
            ]
        }

    @app.post("/api/chat")
    async def chat(request: OllamaChatRequest) -> Dict[str, Any]:
        time.sleep(delay)
        user_messages = [m.content for m in request.messages if m.role == "user"]
        last_user_message = user_messages[-1] if user_messages else ""

        if request.model not in models:
            # Real Ollama would return an error if a model is missing.
            return {
                "model": request.model,
                "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "message": {
                    "role": "assistant",
                    "content": f"Mock warning: {node_name} does not list model {request.model}.",
                },
                "done": True,
            }

        return {
            "model": request.model,
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "message": {
                "role": "assistant",
                "content": (
                    f"Mock response from {node_name} ({hardware_type}) using {request.model}. "
                    f"Prompt preview: {last_user_message[:180]}"
                ),
            },
            "done": True,
            "total_duration": int(delay * 1_000_000_000),
            "load_duration": 1,
            "prompt_eval_count": 10,
            "eval_count": 20,
        }

    return app


def main() -> None:
    parser = argparse.ArgumentParser(description="Run a mock Ollama-compatible node.")
    parser.add_argument("--name", required=True)
    parser.add_argument("--hardware", required=True, choices=["apple_silicon", "nvidia_gpu"])
    parser.add_argument("--port", required=True, type=int)
    parser.add_argument("--models", required=True, help="Comma-separated Ollama model tags")
    parser.add_argument("--delay", type=float, default=0.2)
    args = parser.parse_args()

    models = [model.strip() for model in args.models.split(",") if model.strip()]
    app = create_app(args.name, args.hardware, models, args.delay)
    uvicorn.run(app, host="0.0.0.0", port=args.port)


if __name__ == "__main__":
    main()
