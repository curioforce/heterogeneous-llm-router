# Production Ollama Hardware Router

A FastAPI LLM gateway that routes chat requests to different Ollama servers running on Apple Silicon or NVIDIA GPU nodes.

It supports:

- `mock` mode for local testing without real Ollama servers
- `real` mode for LAN/production Ollama endpoints
- automatic model selection
- Apple Silicon vs NVIDIA routing
- prompt length evaluation
- content type detection: chat, code, analysis, translation, summarization, extraction, creative
- complexity scoring
- health checks
- fallback to another compatible node
- simple circuit breaker behavior
- config-driven node inventory

## Project layout

```text
.
├── app/
│   ├── main.py              # FastAPI app
│   ├── router.py            # routing, fallback, health checks
│   ├── classifier.py        # prompt parsing and model/hardware evaluation
│   ├── clients.py           # Ollama HTTP client
│   ├── config.py            # env + YAML loading
│   ├── registry.py          # runtime node registry and circuit state
│   └── models.py            # request/response schemas
├── config/
│   └── nodes.yaml           # mock and real Ollama node inventory
├── mock_ollama_node.py      # local mock Ollama-compatible server
├── scripts/
│   ├── run_mock_nodes.sh
│   └── run_mock_nvidia.sh
├── requirements.txt
└── .env.example
```

## 1. Install

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

## 2. Run in mock mode

Terminal 1: Apple mock node

```bash
./scripts/run_mock_nodes.sh
```

Terminal 2: NVIDIA mock node

```bash
./scripts/run_mock_nvidia.sh
```

Terminal 3: router

```bash
OLLAMA_ROUTER_MODE=mock uvicorn app.main:app --host 0.0.0.0 --port 9000 --reload
```

## 3. Test small/simple routing

No model is supplied. The router chooses the model automatically.

```bash
curl -s -X POST http://localhost:9000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "messages": [
      {"role": "user", "content": "Explain Apple Silicon routing simply."}
    ],
    "temperature": 0.7,
    "max_tokens": 300,
    "priority": "normal"
  }' | python -m json.tool
```

Expected behavior:

- selected tier: `small`
- selected model: `llama3.1:8b`
- backend hardware: `apple_silicon`

## 4. Test code routing

```bash
curl -s -X POST http://localhost:9000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "messages": [
      {"role": "user", "content": "Fix this Python traceback and refactor the code for production: Traceback (most recent call last): ..."}
    ],
    "temperature": 0.2,
    "max_tokens": 1200,
    "priority": "normal"
  }' | python -m json.tool
```

Expected behavior:

- selected tier: `code`
- selected model: `qwen2.5-coder:32b` if NVIDIA is available
- backend hardware: `nvidia_gpu`

## 5. Test analysis / heavy task routing

```bash
curl -s -X POST http://localhost:9000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "messages": [
      {"role": "user", "content": "Analyze this production architecture, compare tradeoffs, identify risks, and create a scalable deployment strategy."}
    ],
    "temperature": 0.5,
    "max_tokens": 2000,
    "priority": "high"
  }' | python -m json.tool
```

Expected behavior:

- selected tier: `large`
- selected model: `qwen2.5:72b`
- backend hardware: `nvidia_gpu`

## 6. Inspect routing without generating

```bash
curl -s -X POST http://localhost:9000/route/evaluate \
  -H "Content-Type: application/json" \
  -d '{
    "messages": [
      {"role": "user", "content": "Summarize this short email."}
    ],
    "max_tokens": 300,
    "priority": "normal"
  }' | python -m json.tool
```

## 7. Inspect nodes

```bash
curl -s http://localhost:9000/nodes | python -m json.tool
```

## 8. Use real Ollama servers

Edit `config/nodes.yaml` and enable your real nodes:

```yaml
real_nodes:
  - name: apple-mac-mini-m4
    hardware_type: apple_silicon
    base_url: http://192.168.1.50:11434
    enabled: true
    capacity_score: 6
    max_context_tokens: 32768
    models:
      small: llama3.1:8b
      medium: qwen2.5:14b
      code: qwen2.5-coder:7b

  - name: nvidia-rtx4090-node
    hardware_type: nvidia_gpu
    base_url: http://192.168.1.60:11434
    enabled: true
    capacity_score: 24
    max_context_tokens: 131072
    models:
      small: llama3.1:8b
      medium: qwen2.5:32b
      large: qwen2.5:72b
      code: qwen2.5-coder:32b
```

Make sure the models exist on each Ollama node:

```bash
ollama pull llama3.1:8b
ollama pull qwen2.5:14b
ollama pull qwen2.5:32b
ollama pull qwen2.5:72b
ollama pull qwen2.5-coder:7b
ollama pull qwen2.5-coder:32b
```

Then run:

```bash
OLLAMA_ROUTER_MODE=real uvicorn app.main:app --host 0.0.0.0 --port 9000
```

## 9. Routing policy summary

The router evaluates the request using:

- approximate prompt token count
- requested `max_tokens`
- content type
- code/error patterns
- complexity keywords
- priority
- optional `preferred_hardware`
- configured model availability
- node health
- current active requests
- node capacity score

Default policy:

| Request type | Model tier | Hardware preference |
|---|---:|---|
| Short/simple chat | small | Apple Silicon |
| Translation / summarization / extraction | small or medium | Apple Silicon unless long/complex |
| Analysis / architecture / strategy | medium or large | NVIDIA if complex/high priority |
| Code / debugging / refactoring | code | NVIDIA |
| Very long prompt | large | NVIDIA |
| Low priority | small/medium | Apple Silicon preferred |
| High priority | large | NVIDIA preferred |

## 10. Notes for production hardening

This reference is production-shaped, but before internet-facing use, add:

- authentication and per-tenant rate limits
- request body size limits
- structured logs shipped to your logging platform
- Prometheus/OpenTelemetry metrics
- TLS termination through a reverse proxy
- persistence for node health/circuit state if you run multiple router replicas
- streaming support if needed, with careful fallback semantics
- a real tokenizer for each model family
- queue depth or GPU/Metal memory metrics from each node
