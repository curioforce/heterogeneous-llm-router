#!/usr/bin/env bash
set -euo pipefail

python mock_ollama_node.py \
  --name apple-mock-1 \
  --hardware apple_silicon \
  --port 8101 \
  --models llama3.1:8b,qwen2.5:14b,qwen2.5-coder:7b
