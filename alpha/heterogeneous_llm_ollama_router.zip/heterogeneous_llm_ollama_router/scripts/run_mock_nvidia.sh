#!/usr/bin/env bash
set -euo pipefail

python mock_ollama_node.py \
  --name nvidia-mock-1 \
  --hardware nvidia_gpu \
  --port 8102 \
  --models llama3.1:8b,qwen2.5:32b,qwen2.5:72b,qwen2.5-coder:32b
